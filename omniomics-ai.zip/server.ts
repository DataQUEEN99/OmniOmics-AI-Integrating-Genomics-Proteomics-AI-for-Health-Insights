import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import multer from "multer";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || "omniomics_super_secret";
const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json());

  // Database setup
  const db = new Database("./omniomics.db");

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE,
      password TEXT,
      role TEXT DEFAULT 'researcher',
      name TEXT
    );

    CREATE TABLE IF NOT EXISTS datasets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      type TEXT,
      organism TEXT,
      tissue TEXT,
      condition TEXT,
      file_path TEXT,
      uploaded_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS analyses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dataset_id INTEGER,
      type TEXT,
      results TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Simple Seeding
  const adminExists = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
  if (!adminExists) {
    const hashedAdminPassword = await bcrypt.hash("admin123", 10);
    db.prepare("INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)").run(
      "admin@omniomics.ai", hashedAdminPassword, "System Administrator", "admin"
    );
    console.log("Admin account seeded: admin@omniomics.ai / admin123");
  }

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // API Routes
  app.post("/api/auth/signup", async (req, res) => {
    const { email, password, name } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    try {
      const result = db.prepare("INSERT INTO users (email, password, name) VALUES (?, ?, ?)").run(
        email, hashedPassword, name
      );
      res.json({ id: result.lastInsertRowid, email, name });
    } catch (err) {
      res.status(400).json({ error: "Email already exists" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  });

  // Dataset Routes
  const upload = multer({ dest: "uploads/" });
  app.post("/api/datasets/upload", authenticate, upload.single("file"), async (req, res) => {
    const { name, type, organism, tissue, condition } = req.body;
    const filePath = req.file?.path;
    const result = db.prepare("INSERT INTO datasets (name, type, organism, tissue, condition, file_path, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
      name, type, organism, tissue, condition, filePath, (req as any).user.id
    );
    res.json({ id: result.lastInsertRowid, name, type });
  });

  app.get("/api/datasets", authenticate, async (req, res) => {
    const datasets = db.prepare("SELECT * FROM datasets ORDER BY created_at DESC").all();
    res.json(datasets);
  });

  // Admin Routes
  app.get("/api/admin/users", authenticate, async (req, res) => {
    if ((req as any).user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
    const users = db.prepare("SELECT id, email, name, role FROM users").all();
    res.json(users);
  });

  // Vite setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`OmniOmics AI server running on http://localhost:${PORT}`);
  });
}

startServer();
