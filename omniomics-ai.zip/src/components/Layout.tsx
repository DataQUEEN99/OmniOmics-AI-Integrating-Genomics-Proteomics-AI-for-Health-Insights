import { Link, useLocation, Outlet } from 'react-router-dom';
import { LayoutDashboard, Upload as UploadIcon, BarChart3, MessageSquare, ShieldAlert, LogOut, Dna, Database, FileText } from 'lucide-react';
import { User } from '../types';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface SidebarProps {
  user: User;
  onLogout: () => void;
}

export default function Layout({ user, onLogout }: SidebarProps) {
  const location = useLocation();

  const menuItems = [
    { name: 'Dash', path: '/dashboard', icon: LayoutDashboard },
    { name: 'Upload', path: '/upload', icon: UploadIcon },
    { name: 'Analyze', path: '/analysis', icon: BarChart3 },
    { name: 'AI Node', path: '/ai-chat', icon: MessageSquare },
    { name: 'Reports', path: '/reports', icon: FileText },
    ...(user.role === 'admin' ? [{ name: 'Admin', path: '/admin', icon: ShieldAlert }] : []),
  ];

  return (
    <div className="flex h-screen bg-bg-deep text-slate-200 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 bg-[#020305] border-r border-slate-800 flex flex-col items-center py-6 z-20">
        <div className="w-10 h-10 bg-accent-cyan rounded-lg flex items-center justify-center font-black text-black mb-12 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
          OO
        </div>

        <nav className="flex-1 flex flex-col gap-6">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              title={item.name}
              className={cn(
                "p-3 rounded-xl transition-all duration-300 relative group",
                location.pathname === item.path 
                  ? "text-accent-cyan bg-accent-cyan/10" 
                  : "text-slate-500 hover:text-white hover:bg-slate-800/50"
              )}
            >
              {location.pathname === item.path && (
                <motion.div 
                  layoutId="active-bar"
                  className="absolute left-[-1.25rem] w-1 h-6 bg-accent-cyan rounded-full"
                />
              )}
              <item.icon className="w-6 h-6" />
              <span className="absolute left-full ml-4 px-2 py-1 bg-slate-900 border border-slate-800 rounded text-[10px] uppercase tracking-widest font-bold opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                {item.name}
              </span>
            </Link>
          ))}
        </nav>

        <div className="flex flex-col gap-4 items-center">
          <div className="w-10 h-10 rounded-full border border-slate-800 bg-slate-900 flex items-center justify-center text-xs font-bold text-slate-400 overflow-hidden">
            {user.name.charAt(0)}
          </div>
          <button 
            onClick={onLogout}
            className="p-3 rounded-xl text-slate-500 hover:text-red-400 hover:bg-red-500/5 transition-all"
            title="Sign Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-20 border-b border-slate-800/50 flex items-center justify-between px-8 bg-bg-deep/50 backdrop-blur-sm z-10">
          <div className="flex flex-col">
            <h1 className="text-xl font-bold text-white tracking-tight">
              OmniOmics <span className="text-accent-cyan">AI</span>
            </h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-medium">RESEARCH_HUB | PROJECT_REF: {new Date().getFullYear()}</p>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-white">{user.name}</p>
                <p className="text-[10px] text-accent-cyan uppercase tracking-widest font-medium">{user.role}</p>
             </div>
             <div className="w-8 h-8 rounded-full border border-accent-cyan/30 bg-accent-cyan/10" />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 relative">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </div>
      </main>
    </div>
  );
}
