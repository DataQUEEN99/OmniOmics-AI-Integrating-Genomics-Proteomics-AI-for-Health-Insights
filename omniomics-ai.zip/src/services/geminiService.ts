import { GoogleGenAI, Type } from "@google/genai";

const AI_MODEL = "gemini-3-flash-preview";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is not defined. AI features will be disabled.");
    }
    this.ai = new GoogleGenAI({ apiKey: apiKey || "" });
  }

  async analyzeDataset(datasetInfo: string, userQuery: string) {
    try {
      const response = await this.ai.models.generateContent({
        model: AI_MODEL,
        contents: `
          You are OmniOmics AI, an enterprise bioinformatics assistant.
          Context: The user is analyzing the following dataset: ${datasetInfo}.
          
          User Question: ${userQuery}
          
          Guidelines:
          - Provide biological insights based on omics markers.
          - Suggest potential pathways (e.g. apoptosis, MAPK).
          - Identify possible biomarkers or key regulated genes mentioned in the context.
          - Use technical but accessible language.
          - Format response with clear headings and bullet points.
        `,
      });
      return response.text;
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "I encountered an error while processing your request. Please check systemic integrity.";
    }
  }

  async summarizeResult(results: any) {
    try {
      const response = await this.ai.models.generateContent({
        model: AI_MODEL,
        contents: `
          Analyze these omics analysis results and provide a high-level biological summary:
          ${JSON.stringify(results)}
          
          Target: Executive summary for principal investigators.
        `,
      });
      return response.text;
    } catch (error) {
       console.error("Gemini API Error:", error);
       return "Failed to generate summary.";
    }
  }
}

export const gemini = new GeminiService();
