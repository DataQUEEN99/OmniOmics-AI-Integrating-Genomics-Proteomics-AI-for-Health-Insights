export interface User {
  id: number;
  email: string;
  name: string;
  role: 'researcher' | 'admin';
}

export interface Dataset {
  id: number;
  name: string;
  type: 'Genomics' | 'Transcriptomics' | 'Proteomics' | 'Metabolomics';
  organism: string;
  tissue: string;
  condition: string;
  created_at: string;
  uploaded_by: number;
}

export interface AnalysisResult {
  id: number;
  dataset_id: number;
  type: string;
  results: any;
  created_at: string;
}

export interface PathwayResult {
  name: string;
  score: number;
  pValue: number;
  genes: string[];
}
