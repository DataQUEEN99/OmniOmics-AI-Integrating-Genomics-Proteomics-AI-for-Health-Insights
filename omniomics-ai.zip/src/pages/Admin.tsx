import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Users, Database, ArrowRight, Trash2, Key, UserCheck } from 'lucide-react';
import { User, Dataset } from '../types';

export default function Admin() {
  const [users, setUsers] = useState<User[]>([]);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [uRes, dRes] = await Promise.all([
          fetch('/api/admin/users', { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } }),
          fetch('/api/datasets', { headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } })
        ]);
        const uData = await uRes.json();
        const dData = await dRes.json();
        setUsers(uData);
        setDatasets(dData);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight mb-2 italic serif text-amber-500">ADMIN_OVERRIDE</h2>
          <p className="text-[#8E9299] font-mono text-xs uppercase tracking-widest">CONTROL_LEVEL: OMNISCIENT • SESSION_SECURE</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* User Management */}
        <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Users className="w-32 h-32 text-cyan-500" />
          </div>
          <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-8 flex items-center gap-2">
            <Users className="w-4 h-4 text-cyan-500" />
            Personnel Registry
          </h3>
          
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.id} className="p-4 bg-[#111] rounded-2xl border border-[#222] flex items-center justify-between group hover:border-[#333] transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#1A1A1A] flex items-center justify-center text-xs font-mono font-bold text-cyan-500">
                    {user.id}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{user.name}</h4>
                    <p className="text-[10px] text-[#4A4A4A] uppercase tracking-widest">{user.email} • {user.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                   <button className="p-2 text-[#4A4A4A] hover:text-cyan-500 transition-colors">
                      <Key className="w-4 h-4" />
                   </button>
                   <button className="p-2 text-[#4A4A4A] hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                   </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Dataset Audit */}
        <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-8 relative overflow-hidden">
           <div className="absolute top-0 right-0 p-8 opacity-5">
            <Database className="w-32 h-32 text-purple-500" />
          </div>
          <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-8 flex items-center gap-2">
            <Database className="w-4 h-4 text-purple-500" />
            Central Data Repository
          </h3>
          <div className="space-y-4">
            {datasets.map((ds) => (
              <div key={ds.id} className="p-4 bg-[#111] rounded-2xl border border-[#222] flex items-center justify-between group hover:border-[#333] transition-all">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#1A1A1A] flex items-center justify-center text-[10px] font-mono font-bold text-purple-500">
                    {ds.type.substring(0, 1)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{ds.name}</h4>
                    <p className="text-[10px] text-[#4A4A4A] uppercase tracking-widest">{ds.organism} • {ds.condition}</p>
                  </div>
                </div>
                <button className="p-2 text-[#4A4A4A] hover:text-purple-500 transition-colors">
                   <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
            {datasets.length === 0 && <p className="text-center text-[#4A4A4A] text-xs py-8">NO DATASETS REGISTERED</p>}
          </div>
        </div>
      </div>

       {/* Audit Log */}
       <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-8">
          <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-8 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-500" />
            System Audit Log
          </h3>
          <div className="font-mono text-[10px] space-y-2 opacity-30">
             <p>[OK] {new Date().toISOString()} - DATABASE_SYNC: COMPLETED</p>
             <p>[OK] {new Date().toISOString()} - NEURAL_LINK: STABLE</p>
             <p>[OK] {new Date().toISOString()} - USER_REGISTRY_VERIFIED</p>
             <p>[INFO] {new Date().toISOString()} - AUTO_PURGE_PENDING</p>
          </div>
       </div>
    </div>
  );
}
