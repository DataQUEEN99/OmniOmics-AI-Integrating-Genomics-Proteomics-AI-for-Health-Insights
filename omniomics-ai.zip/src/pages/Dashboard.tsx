import { motion } from 'motion/react';
import { Database, BarChart3, TrendingUp, AlertTriangle, Activity, FlaskConical, Microscope } from 'lucide-react';
import { cn } from '../lib/utils';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockData = [
  { name: 'Jan', count: 40 },
  { name: 'Feb', count: 70 },
  { name: 'Mar', count: 45 },
  { name: 'Apr', count: 90 },
  { name: 'May', count: 120 },
  { name: 'Jun', count: 150 },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white mb-1">HUB_OVERVIEW</h2>
          <p className="text-slate-500 font-mono text-[10px] tracking-[0.2em] uppercase font-bold">SYSTEM_REF: BRCA-X-901</p>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-accent-cyan animate-pulse shadow-[0_0_8px_#22D3EE]" />
            <span className="text-[10px] uppercase font-bold tracking-[0.1em] text-slate-500">Node: Stable</span>
          </div>
          <div className="flex items-center gap-2">
             <Activity className="w-4 h-4 text-accent-cyan" />
            <span className="text-[10px] uppercase font-bold tracking-[0.1em] text-slate-500">Processing: Idle</span>
          </div>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Sequenced Genes" 
          value="24,102" 
          change="+1.2%" 
          icon={Database} 
          trend="up" 
        />
        <StatsCard 
          title="Sig. Biomarkers" 
          value="184" 
          change="FDR < 0.05" 
          icon={FlaskConical} 
          trend="up" 
          accent
        />
        <StatsCard 
          title="Datasets Loaded" 
          value="14" 
          change="6 Trans" 
          icon={BarChart3} 
          trend="up" 
        />
        <StatsCard 
          title="AI Pipeline Status" 
          value="72%" 
          change="Analyzing..." 
          icon={Activity} 
          trend="up" 
          progressBar
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-8 glass-card p-6 relative overflow-hidden group">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <Activity className="w-3 h-3 text-accent-cyan" />
              Dataset Throughput
            </h3>
            <div className="flex gap-2">
               <span className="px-2 py-1 bg-slate-800 rounded text-[10px] text-slate-400 border border-slate-700">6 Months</span>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockData}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22D3EE" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#22D3EE" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(31,41,55,0.5)" />
                <XAxis 
                  dataKey="name" 
                  stroke="#475569" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={10}
                />
                <YAxis 
                  stroke="#475569" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  dx={-10}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0D1117', borderColor: '#1F2937', color: '#fff', borderRadius: '8px', fontSize: '10px' }}
                  itemStyle={{ color: '#22D3EE' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#22D3EE" 
                  fillOpacity={1} 
                  fill="url(#colorCount)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sidebar Mini List */}
        <div className="lg:col-span-4 glass-card p-6 flex flex-col">
          <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-6">Recent Payload Log</h3>
          <div className="space-y-3 flex-1">
            {[
              { name: 'BRCA-Sample-G1', type: 'Genomics', date: '2h ago', status: 'ready' },
              { name: 'LUAD-Pro-Batch7', type: 'Proteomics', date: '5h ago', status: 'processing' },
              { name: 'CRC-Meta-CTRL', type: 'Metabolomics', date: '1d ago', status: 'ready' },
              { name: 'STAD-Trans-01', type: 'Transcriptomics', date: '2d ago', status: 'ready' },
            ].map((dataset, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-slate-900/30 rounded-xl border border-slate-800/50 hover:border-accent-cyan/30 transition-all cursor-pointer group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-800/50 flex items-center justify-center group-hover:bg-accent-cyan/10 transition-colors">
                    <Microscope className="w-4 h-4 text-slate-500 group-hover:text-accent-cyan" />
                  </div>
                  <div>
                    <h4 className="text-[11px] font-bold text-white uppercase tracking-tight">{dataset.name}</h4>
                    <p className="text-[9px] text-slate-500 uppercase tracking-widest">{dataset.type}</p>
                  </div>
                </div>
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full shrink-0",
                  dataset.status === 'ready' ? "bg-accent-cyan shadow-[0_0_5px_#22D3EE]" : "bg-amber-500 animate-pulse"
                )} />
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2.5 bg-slate-800 rounded-lg text-[10px] font-bold uppercase tracking-[0.2em] text-slate-300 hover:bg-slate-700 transition-all">
            Access Full Registry
          </button>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, value, change, icon: Icon, accent, progressBar }: any) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "glass-card p-5 relative overflow-hidden group",
        accent && "border-accent-cyan/40 bg-accent-cyan/5"
      )}
    >
      <p className="text-[10px] uppercase font-bold tracking-[0.2em] text-slate-500 mb-2">{title}</p>
      <div className="flex items-end justify-between">
        <h4 className="text-2xl font-bold text-white tracking-tight">{value}</h4>
        <span className={cn(
          "text-[10px] font-bold",
          accent ? "text-accent-cyan" : "text-green-500"
        )}>
          {change}
        </span>
      </div>
      
      {progressBar ? (
        <div className="mt-4 h-1 w-full bg-slate-800 rounded-full overflow-hidden">
           <div className="h-full bg-accent-cyan rounded-full cyan-glow" style={{ width: value }} />
        </div>
      ) : (
        <div className="absolute top-4 right-4 opacity-10 group-hover:opacity-20 translate-x-2 -translate-y-2 group-hover:translate-x-0 group-hover:translate-y-0 transition-all duration-500">
          <Icon className="w-12 h-12" />
        </div>
      )}
    </motion.div>
  );
}
