import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, Send, Bot, User, Loader2, Dna, Terminal, Share2, Download, Eraser } from 'lucide-react';
import { gemini } from '../services/geminiService';
import { cn } from '../lib/utils';
import ReactMarkdown from 'react-markdown';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "System online. I am OmniOmics AI. Select a dataset or ask a biological question to begin analysis.",
      timestamp: new Date().toLocaleTimeString()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await gemini.analyzeDataset("Demo Dataset (Genomics, Homo sapiens)", input);
      const botMessage: Message = {
        role: 'assistant',
        content: response || "Analysis failed to materialize.",
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-[calc(100vh-160px)] flex flex-col space-y-6">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight mb-2 italic serif">NEURAL_INTERPRETER</h2>
          <p className="text-[#8E9299] font-mono text-xs uppercase tracking-widest">GEMINI_ENGINE_3.0 • SECURE_CHANNEL_ENCRYPTED</p>
        </div>
        <div className="flex gap-3">
           <button 
             onClick={() => setMessages([messages[0]])}
             className="p-2 bg-[#111] border border-[#222] rounded-lg text-[#4A4A4A] hover:text-white transition-all"
           >
             <Eraser className="w-5 h-5" />
           </button>
           <button className="p-2 bg-[#111] border border-[#222] rounded-lg text-[#4A4A4A] hover:text-white transition-all">
             <Share2 className="w-5 h-5" />
           </button>
        </div>
      </header>

      <div className="flex-1 min-h-0 glass-card flex flex-col relative overflow-hidden">
        {/* Background Grid Accent */}
        <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[linear-gradient(to_right,#22D3EE_1px,transparent_1px),linear-gradient(to_bottom,#22D3EE_1px,transparent_1px)] bg-[size:32px_32px]" />
        
        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-hide">
          {messages.map((msg, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              key={idx}
              className={cn(
                "flex gap-6 max-w-4xl mx-auto",
                msg.role === 'user' ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border",
                msg.role === 'user' 
                  ? "bg-slate-800 border-slate-700 text-slate-400" 
                  : "bg-accent-cyan/10 border-accent-cyan/20 text-accent-cyan"
              )}>
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              <div className={cn(
                "space-y-2 max-w-[80%]",
                msg.role === 'user' ? "items-end" : "items-start"
              )}>
                <div className="flex items-center gap-3 opacity-40">
                  <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">
                    {msg.role === 'user' ? 'RESEARCHER' : 'AI_ENGINE'}
                  </span>
                  <span className="text-[9px] font-mono text-slate-600">{msg.timestamp}</span>
                </div>
                <div className={cn(
                  "p-5 rounded-2xl text-sm leading-relaxed relative",
                  msg.role === 'user' 
                    ? "bg-slate-900/50 text-slate-300 border border-slate-800" 
                    : "bg-slate-800/20 text-slate-200 border border-border-slate font-sans"
                )}>
                  {msg.role === 'assistant' ? (
                    <div className="markdown-body prose prose-invert prose-sm max-w-none">
                      <ReactMarkdown>{msg.content}</ReactMarkdown>
                    </div>
                  ) : (
                    <p>{msg.content}</p>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
          
          {isTyping && (
            <div className="flex gap-6 max-w-4xl mx-auto">
              <div className="w-10 h-10 rounded-2xl bg-accent-cyan/10 border border-accent-cyan/20 flex items-center justify-center text-accent-cyan shrink-0">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
              <div className="space-y-2">
                 <div className="flex items-center gap-3 opacity-40">
                  <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">AI_ENGINE</span>
                  <span className="text-[9px] font-mono text-accent-cyan animate-pulse uppercase tracking-widest">SYNTHESIZING...</span>
                </div>
                <div className="p-5 rounded-2xl bg-slate-800/20 border border-border-slate text-accent-cyan/50">
                  <span className="animate-pulse">● ● ●</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-6 border-t border-slate-800/50 bg-[#020305]/50 backdrop-blur-md relative z-10">
          <form onSubmit={handleSend} className="max-w-4xl mx-auto relative group">
            <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none opacity-30 group-focus-within:opacity-100 transition-opacity">
              <Terminal className="w-4 h-4 text-accent-cyan" />
            </div>
            <input
              type="text"
              placeholder="Query the multi-omics database..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-14 pr-24 text-sm text-white focus:border-accent-cyan focus:ring-1 focus:ring-accent-cyan transition-all outline-none"
            />
            <button
              type="submit"
              disabled={!input.trim() || isTyping}
              className={cn(
                "absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-xl transition-all font-bold text-xs uppercase tracking-widest",
                input.trim() && !isTyping ? "bg-accent-cyan text-black" : "bg-slate-800 text-slate-500"
              )}
            >
              Analyze
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
