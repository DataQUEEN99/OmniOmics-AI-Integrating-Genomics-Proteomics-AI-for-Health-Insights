import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { FileText, Download, Printer, Share2, Mail, CheckCircle2, Loader2, Info } from 'lucide-react';

export default function Reports() {
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState(false);

  const handleGenerate = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setGenerated(true);
    }, 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <header className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight mb-2 italic serif">REPORT_GENERATOR</h2>
          <p className="text-[#8E9299] font-mono text-xs uppercase tracking-widest">COMPILE MULTI-OMICS INSIGHTS INTO FORMAL DOCS</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-8">
             <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-cyan-500/10 rounded-2xl border border-cyan-500/20">
                   <FileText className="w-6 h-6 text-cyan-500" />
                </div>
                <div>
                   <h3 className="text-xl font-bold text-white">Consolidated Analysis Report</h3>
                   <p className="text-sm text-[#4A4A4A]">Select sections to include in the final synthesis</p>
                </div>
             </div>

             <div className="space-y-4">
                {[
                  { name: 'Dataset Metadata', desc: 'Organism, tissue, condition & quality scores' },
                  { name: 'Differential Expression', desc: 'Volcano plots and significantly regulated genes' },
                  { name: 'Pathway Enrichment', desc: 'Enriched signaling pathways with p-values' },
                  { name: 'AI Biological Interpretation', desc: 'Gemini-powered insights and biomarker suggestions' },
                  { name: 'Quality Control Summary', desc: 'Normalization trends and batch effect reports' },
                ].map((section, idx) => (
                  <div key={idx} className="p-4 bg-[#111] rounded-2xl border border-[#222] flex items-center justify-between group hover:border-cyan-500/30 transition-all cursor-pointer">
                    <div className="flex items-center gap-4">
                       <input type="checkbox" defaultChecked className="w-5 h-5 accent-cyan-500 bg-[#1A1A1A] border-[#222] rounded" />
                       <div>
                          <h4 className="text-sm font-bold text-white mb-0.5">{section.name}</h4>
                          <p className="text-[10px] text-[#4A4A4A] uppercase tracking-widest">{section.desc}</p>
                       </div>
                    </div>
                  </div>
                ))}
             </div>

             <button 
               onClick={handleGenerate}
               disabled={loading}
               className="w-full mt-8 py-4 bg-cyan-500 text-black font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-cyan-400 transition-all active:scale-95 transition-transform"
             >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    COMPILING_RESOURCES...
                  </>
                ) : (
                  <>
                    <Printer className="w-5 h-5" />
                    GENERATE_MASTER_REPORT
                  </>
                )}
             </button>
          </div>

          {generated && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-8 bg-green-500/5 border border-green-500/20 rounded-3xl flex items-center justify-between"
            >
               <div className="flex items-center gap-4">
                  <CheckCircle2 className="w-10 h-10 text-green-500" />
                  <div>
                     <h4 className="text-lg font-bold text-white leading-none mb-1">Report Generated</h4>
                     <p className="text-sm text-green-500/60">OMNI_OMICS_REPORT_V1_PDF</p>
                  </div>
               </div>
               <div className="flex gap-4">
                  <button className="p-3 bg-white text-black rounded-xl hover:bg-gray-200 transition-all">
                     <Download className="w-5 h-5" />
                  </button>
                  <button className="p-3 bg-white text-black rounded-xl hover:bg-gray-200 transition-all">
                     <Mail className="w-5 h-5" />
                  </button>
               </div>
            </motion.div>
          )}
        </div>

        <div className="space-y-8">
           <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-6">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-6 opacity-50">Report Templates</h3>
              <div className="space-y-3">
                 {['Clinical Summary', 'Research Deep-Dive', 'Executive Review', 'Raw Data Archive'].map(t => (
                   <button key={t} className="w-full text-left p-4 bg-[#111] border border-[#222] rounded-xl text-xs font-bold text-[#8E9299] hover:text-white hover:border-cyan-500/30 transition-all">
                      {t}
                   </button>
                 ))}
              </div>
           </div>

           <div className="p-6 bg-cyan-500/5 rounded-3xl border border-cyan-500/10">
              <div className="flex items-center gap-2 mb-4">
                 <Info className="w-4 h-4 text-cyan-500" />
                 <h4 className="text-[10px] uppercase font-bold text-cyan-400 tracking-widest">Security Protocol</h4>
              </div>
              <p className="text-[10px] text-cyan-500/60 leading-relaxed uppercase tracking-wider">
                All generated reports are watermark-signed with your researcher identity and encrypted with institutional-grade AES-256 before distribution.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
