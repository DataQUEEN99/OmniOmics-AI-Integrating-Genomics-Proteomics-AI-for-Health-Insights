import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Dna, ChevronRight, BarChart3, Shield, Globe, Award } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-[#050505]/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Dna className="w-8 h-8 text-cyan-500" />
            <span className="text-xl font-bold tracking-tighter">OMNI<span className="text-cyan-500">OMICS</span> AI</span>
          </div>
          <div className="flex items-center gap-8">
            <Link to="/login" className="text-sm font-medium text-gray-400 hover:text-white transition-colors">Sign In</Link>
            <Link to="/signup" className="px-5 py-2.5 bg-white text-black text-sm font-bold rounded-lg hover:bg-gray-200 transition-all">Get Started</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 px-6">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500 rounded-full blur-[128px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600 rounded-full blur-[128px]" />
        </div>

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block py-1.5 px-4 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-bold tracking-[0.2em] uppercase mb-8">
              BEYOND THE GENOME
            </span>
            <h1 className="text-7xl md:text-8xl font-bold tracking-tight mb-8 leading-[0.9]">
              Master the Complexity of <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-400 to-blue-500">Multi-Omics.</span>
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12 leading-relaxed">
              Accelerate clinical insights with the enterprise AI engine for genomics, 
              transcriptomics, and deep biological data interpretation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link to="/signup" className="group px-8 py-4 bg-cyan-500 text-black font-bold rounded-xl flex items-center gap-2 hover:bg-cyan-400 transition-all scale-105">
                Launch Platform
                <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <button className="px-8 py-4 border border-white/10 rounded-xl font-bold hover:bg-white/5 transition-all">
                Request Demo
              </button>
            </div>
          </motion.div>
        </div>

        {/* Feature Teasers */}
        <div className="max-w-7xl mx-auto mt-32 grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={BarChart3} 
            title="Neural Analysis" 
            description="Parallel multi-omics pipelines delivering insights at Peta-scale speeds." 
          />
          <FeatureCard 
            icon={Shield} 
            title="Enterprise Secure" 
            description="SOC2 compliant infrastructure for clinical-grade sensitive data." 
          />
          <FeatureCard 
            icon={Globe} 
            title="Global Synthesis" 
            description="Automatic cross-organism and tissue-type normalization." 
          />
        </div>
      </section>

      {/* Scientific Backdrop */}
      <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-cyan-500/5 to-transparent pointer-events-none" />
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: any) {
  return (
    <div className="p-8 rounded-3xl bg-[#0A0A0A] border border-white/5 hover:border-cyan-500/30 transition-all group">
      <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
        <Icon className="w-6 h-6 text-cyan-500" />
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
    </div>
  );
}
