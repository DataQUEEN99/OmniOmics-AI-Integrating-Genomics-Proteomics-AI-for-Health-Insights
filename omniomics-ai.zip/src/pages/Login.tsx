import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Dna, Mail, Lock, ChevronRight } from 'lucide-react';
import { User } from '../types';

export default function Login({ onLogin }: { onLogin: (user: User) => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      onLogin(data.user);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-bg-deep flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Grid Accent */}
      <div className="absolute inset-0 opacity-[0.05] pointer-events-none bg-[linear-gradient(to_right,#22D3EE_1px,transparent_1px),linear-gradient(to_bottom,#22D3EE_1px,transparent_1px)] bg-[size:48px_48px]" />
      
      <div className="w-full max-w-md relative">
        <div className="flex flex-col items-center mb-12">
          <div className="w-16 h-16 bg-accent-cyan rounded-2xl flex items-center justify-center font-black text-black text-2xl shadow-[0_0_30px_rgba(34,211,238,0.4)] mb-8">
            OO
          </div>
          <h2 className="text-3xl font-bold text-white tracking-tight text-center">OMNI<span className="text-accent-cyan">OMICS</span> AI</h2>
          <p className="text-slate-500 text-[10px] uppercase font-bold tracking-[0.3em] mt-3">Biological Intelligence Interface</p>
        </div>

        <div className="glass-card p-1">
          <form onSubmit={handleSubmit} className="p-8 space-y-4">
            {error && <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-bold text-center uppercase tracking-widest">{error}</div>}
            
            <div className="space-y-1">
              <label className="text-[9px] uppercase font-bold text-slate-500 tracking-widest ml-1">Registry Email</label>
              <div className="relative">
                <input
                  type="email"
                  placeholder="name@institution.ai"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-xl py-4 px-4 text-sm text-white focus:border-accent-cyan transition-all outline-none"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] uppercase font-bold text-slate-500 tracking-widest ml-1">Security Key</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-xl py-4 px-4 text-sm text-white focus:border-accent-cyan transition-all outline-none"
                  required
                />
              </div>
            </div>

            <button type="submit" className="w-full py-4 bg-accent-cyan text-black font-black text-xs tracking-[0.2em] rounded-xl flex items-center justify-center gap-2 hover:brightness-110 transition-all mt-6 shadow-[0_0_20px_rgba(34,211,238,0.2)]">
              INITIATE_SESSION
            </button>
          </form>
        </div>

        <p className="text-center mt-12 text-[10px] uppercase tracking-[0.1em] text-slate-600 font-bold">
          Authorization required for data access. <Link to="/signup" className="text-accent-cyan hover:underline">Register Identity</Link>
        </p>
      </div>
    </div>
  );
}
