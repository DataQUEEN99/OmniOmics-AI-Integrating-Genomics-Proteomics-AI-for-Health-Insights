import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { BarChart3, ScatterChart as ScatterIcon, Activity, FlaskConical, Microscope, FileText, Download, Share2 } from 'lucide-react';
import { cn } from '../lib/utils';
import { 
  ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, Legend, Cell, ComposedChart, Line
} from 'recharts';

// Mock generator for data
const generateVolcanoData = () => {
  return Array.from({ length: 400 }, () => {
    const logFC = (Math.random() - 0.5) * 8;
    const pVal = Math.random() * 10;
    let category = 'NS';
    if (pVal > 6 && logFC > 1.5) category = 'UP';
    if (pVal > 6 && logFC < -1.5) category = 'DOWN';
    return { logFC, pVal, category, name: `Gene_${Math.floor(Math.random() * 1000)}` };
  });
};

const generatePCAData = () => {
  return [
    ...Array.from({ length: 15 }, () => ({ x: Math.random() * 50 + 10, y: Math.random() * 50 + 10, group: 'Group A', z: 1 })),
    ...Array.from({ length: 15 }, () => ({ x: Math.random() * 50 - 60, y: Math.random() * 50 - 40, group: 'Group B', z: 1 })),
  ];
};

export default function Analysis() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<'volcano' | 'pca' | 'pathway'>('volcano');
  const [volcanoData] = useState(generateVolcanoData());
  const [pcaData] = useState(generatePCAData());

  return (
    <div className="space-y-8">
       <header className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight mb-2 italic serif">OMICS_ENGINE_V3</h2>
          <p className="text-[#8E9299] font-mono text-xs uppercase tracking-widest">Dataset ID: {id || 'GLOBAL_VIEW'}</p>
        </div>
        <div className="flex gap-3">
           <button className="flex items-center gap-2 px-4 py-2 bg-[#111] border border-[#222] rounded-lg text-xs font-bold uppercase tracking-widest text-[#8E9299] hover:text-white transition-all">
             <Download className="w-4 h-4" />
             Export PDF
           </button>
           <button className="flex items-center gap-2 px-4 py-2 bg-cyan-500 text-black rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-cyan-400 transition-all">
             <Share2 className="w-4 h-4" />
             Share
           </button>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="flex border-b border-[#141414] gap-8">
        {[
          { id: 'volcano', label: 'Volcano Plot', icon: BarChart3 },
          { id: 'pca', label: 'PCA Analysis', icon: ScatterIcon },
          { id: 'pathway', label: 'Pathway Enrichment', icon: Activity },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "pb-4 text-xs font-bold uppercase tracking-[0.2em] relative transition-all",
              activeTab === tab.id ? "text-cyan-500" : "text-[#4A4A4A] hover:text-[#8E9299]"
            )}
          >
            <span className="flex items-center gap-2">
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </span>
            {activeTab === tab.id && (
              <motion.div layoutId="active-tab" className="absolute bottom-0 left-0 w-full h-[2px] bg-cyan-500" />
            )}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Viz */}
        <div className="lg:col-span-3 space-y-8">
          <div className="glass-card p-8 h-[600px] relative overflow-hidden">
            <AnimatePresence mode="wait">
              {activeTab === 'volcano' && (
                <motion.div 
                  key="volcano"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="h-full w-full"
                >
                  <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-8">Differential Expression Analysis</h4>
                   <ResponsiveContainer width="100%" height="90%">
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(31,41,55,0.5)" />
                      <XAxis type="number" dataKey="logFC" name="log2 Fold Change" stroke="#475569" label={{ value: 'log2 Fold Change', position: 'bottom', fill: '#475569', fontSize: 10 }} />
                      <YAxis type="number" dataKey="pVal" name="-log10 p-value" stroke="#475569" label={{ value: '-log10(p)', angle: -90, position: 'left', fill: '#475569', fontSize: 10 }} />
                      <ZAxis type="number" range={[16, 16]} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0D1117', border: '1px solid rgba(31, 41, 55, 1)', fontSize: '10px' }}
                        cursor={{ strokeDasharray: '3 3' }} 
                        itemStyle={{ color: '#fff' }}
                      />
                      <Scatter name="Non-significant" data={volcanoData.filter(d => d.category === 'NS')} fill="#334155" opacity={0.3} />
                      <Scatter name="Upregulated" data={volcanoData.filter(d => d.category === 'UP')} fill="#EF4444" />
                      <Scatter name="Downregulated" data={volcanoData.filter(d => d.category === 'DOWN')} fill="#3B82F6" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </motion.div>
              )}

              {activeTab === 'pca' && (
                <motion.div 
                  key="pca"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="h-full w-full"
                >
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-8 opacity-50">Principal Component Analysis</h4>
                   <ResponsiveContainer width="100%" height="90%">
                    <ScatterChart>
                      <CartesianGrid strokeDasharray="3 3" stroke="#141414" />
                      <XAxis type="number" dataKey="x" name="PC1" stroke="#4A4A4A" label={{ value: 'PC1 (42%)', position: 'bottom', fill: '#4A4A4A', fontSize: 10 }} />
                      <YAxis type="number" dataKey="y" name="PC2" stroke="#4A4A4A" label={{ value: 'PC2 (18%)', angle: -90, position: 'left', fill: '#4A4A4A', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#111', border: '1px solid #333' }} cursor={{ strokeDasharray: '3 3' }} />
                      <Scatter name="Group 1" data={pcaData.filter(d => d.group === 'Group A')} fill="#06b6d4" />
                      <Scatter name="Group 2" data={pcaData.filter(d => d.group === 'Group B')} fill="#a855f7" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </motion.div>
              )}

              {activeTab === 'pathway' && (
                <motion.div 
                   key="pathway"
                   initial={{ opacity: 0, x: 20 }}
                   animate={{ opacity: 1, x: 0 }}
                   exit={{ opacity: 0, x: -20 }}
                   className="h-full w-full"
                >
                  <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-8 opacity-50">Pathway Enrichment Analysis</h4>
                  <div className="space-y-4">
                    {[
                      { name: 'Apoptosis', score: 0.85, genes: 12, p: '1.2e-4' },
                      { name: 'MAPK Signaling', score: 0.76, genes: 24, p: '4.5e-3' },
                      { name: 'PI3K-AKT Pathway', score: 0.65, genes: 18, p: '2.1e-2' },
                      { name: 'Cell Cycle', score: 0.54, genes: 45, p: '5.6e-2' },
                    ].map((path, idx) => (
                      <div key={idx} className="p-4 bg-[#111] rounded-2xl border border-[#222] flex items-center justify-between group hover:border-cyan-500/30 transition-all">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl bg-cyan-900/10 border border-cyan-500/20 flex items-center justify-center text-cyan-500">
                             <FlaskConical className="w-6 h-6" />
                          </div>
                          <div>
                            <h5 className="text-sm font-bold text-white">{path.name}</h5>
                            <p className="text-[10px] text-[#4A4A4A] uppercase tracking-widest">{path.genes} genes involved • P-val: {path.p}</p>
                          </div>
                        </div>
                        <div className="text-right">
                           <p className="text-xs font-mono text-cyan-400 font-bold">{(path.score * 100).toFixed(0)}%</p>
                           <div className="w-32 h-1 bg-[#222] rounded-full mt-2 overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }} 
                                animate={{ width: `${path.score * 100}%` }}
                                className="h-full bg-cyan-500" 
                              />
                           </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Sidebar Controls/Stats */}
        <div className="space-y-8">
           <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-6">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-6 opacity-50">Filter Controls</h3>
              <div className="space-y-6">
                 <div className="space-y-3">
                   <div className="flex justify-between items-center text-[10px] uppercase font-bold text-[#4A4A4A]">
                      <span>LogFC Threshold</span>
                      <span className="text-cyan-500">1.50</span>
                   </div>
                   <input type="range" className="w-full accent-cyan-500" />
                 </div>
                 <div className="space-y-3">
                   <div className="flex justify-between items-center text-[10px] uppercase font-bold text-[#4A4A4A]">
                      <span>P-Value (-log10)</span>
                      <span className="text-cyan-500">6.00</span>
                   </div>
                   <input type="range" className="w-full accent-cyan-500" />
                 </div>
              </div>
           </div>

           <div className="bg-[#0A0A0A] border border-[#141414] rounded-3xl p-6">
              <h3 className="text-xs font-bold text-white uppercase tracking-widest mb-6 opacity-50">Significance Summary</h3>
              <div className="grid grid-cols-2 gap-4">
                 <div className="p-4 bg-[#111] rounded-2xl border border-[#222]">
                    <p className="text-[10px] uppercase font-bold text-[#4A4A4A] mb-1">UPREG</p>
                    <h5 className="text-xl font-bold text-green-500">42</h5>
                 </div>
                 <div className="p-4 bg-[#111] rounded-2xl border border-[#222]">
                    <p className="text-[10px] uppercase font-bold text-[#4A4A4A] mb-1">DOWNREG</p>
                    <h5 className="text-xl font-bold text-red-500">28</h5>
                 </div>
              </div>
              <div className="mt-4 p-4 bg-cyan-500/5 rounded-2xl border border-cyan-500/10">
                 <p className="text-[10px] uppercase font-bold text-cyan-400 mb-1">Quality Score</p>
                 <h5 className="text-xl font-bold text-cyan-300 tracking-tighter">94.8%</h5>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

function AnimatePresence({ children, mode }: any) {
  return <div className={mode === 'wait' ? 'relative' : ''}>{children}</div>;
}
