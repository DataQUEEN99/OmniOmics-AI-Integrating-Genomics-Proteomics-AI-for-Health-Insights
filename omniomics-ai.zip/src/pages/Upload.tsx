import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload as UploadIcon, FileText, CheckCircle2, Loader2, X, Info } from 'lucide-react';
import { cn } from '../lib/utils';

const OMICS_TYPES = ['Genomics', 'Transcriptomics', 'Proteomics', 'Metabolomics'];
const ORGANISMS = ['Homo sapiens', 'Mus musculus', 'Rattus norvegicus', 'Drosophila melanogaster', 'Arabidopsis thaliana'];

export default function Upload() {
  const [file, setFile] = useState<File | null>(null);
  const [metadata, setMetadata] = useState({
    name: '',
    type: 'Genomics',
    organism: 'Homo sapiens',
    tissue: '',
    condition: ''
  });
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    Object.entries(metadata).forEach(([key, value]) => formData.append(key, value));

    try {
      const res = await fetch('/api/datasets/upload', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });
      if (res.ok) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
        setFile(null);
        setMetadata({ name: '', type: 'Genomics', organism: 'Homo sapiens', tissue: '', condition: '' });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-white tracking-tight mb-2 italic serif">DATA_INGESTION</h2>
          <p className="text-[#8E9299] font-mono text-xs uppercase tracking-widest">SUBMIT MULTI-OMICS DATASETS FOR PROCESSING</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Form */}
        <form onSubmit={handleUpload} className="space-y-6">
          <div className="glass-card p-6 space-y-4">
            <h3 className="text-[10px] font-bold text-accent-cyan uppercase tracking-[0.2em] flex items-center gap-2 mb-4">
              <Info className="w-3 h-3" />
              Metadata Specification
            </h3>
            
            <div className="space-y-2">
              <label className="text-[9px] uppercase font-bold text-slate-500 tracking-widest ml-1">Dataset Alias</label>
              <input
                type="text"
                placeholder="Unique Name (e.g. HEP-202X-S1)"
                value={metadata.name}
                onChange={e => setMetadata({ ...metadata, name: e.target.value })}
                className="w-full bg-slate-900/50 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-accent-cyan transition-all outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[9px] uppercase font-bold text-slate-500 tracking-widest ml-1">Omics Type</label>
                <select
                  value={metadata.type}
                  onChange={e => setMetadata({ ...metadata, type: e.target.value })}
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-accent-cyan transition-all outline-none appearance-none"
                >
                  {OMICS_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[9px] uppercase font-bold text-slate-500 tracking-widest ml-1">Organism</label>
                <select
                  value={metadata.organism}
                  onChange={e => setMetadata({ ...metadata, organism: e.target.value })}
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white focus:border-accent-cyan transition-all outline-none appearance-none"
                >
                  {ORGANISMS.map(o => <option key={o} value={o}>{o}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold text-[#4A4A4A] tracking-wider ml-1">Tissue / Cell Line</label>
              <input
                type="text"
                placeholder="e.g. Liver, HEK293, PBMCs"
                value={metadata.tissue}
                onChange={e => setMetadata({ ...metadata, tissue: e.target.value })}
                className="w-full bg-[#111] border border-[#222] rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 transition-all outline-none"
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold text-[#4A4A4A] tracking-wider ml-1">Experimental Condition</label>
              <input
                type="text"
                placeholder="e.g. Control vs Treated, Disease State"
                value={metadata.condition}
                onChange={e => setMetadata({ ...metadata, condition: e.target.value })}
                className="w-full bg-[#111] border border-[#222] rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 transition-all outline-none"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={!file || uploading}
            className={cn(
              "w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-2",
              file && !uploading 
                ? "bg-cyan-500 text-black hover:bg-cyan-400" 
                : "bg-[#111] text-[#4A4A4A] cursor-not-allowed border border-[#222]"
            )}
          >
            {uploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                UPLOADING_SYSTEM_PAYLOAD
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                INITIATE_INGESTION
              </>
            )}
          </button>
        </form>

        {/* Upload Box */}
        <div className="space-y-6">
          <div className={cn(
            "relative border-2 border-dashed rounded-3xl p-12 transition-all flex flex-col items-center justify-center text-center h-[500px]",
            file ? "border-cyan-500/50 bg-cyan-500/5" : "border-[#141414] hover:border-[#222] bg-[#0A0A0A]"
          )}>
            <input
              type="file"
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={handleFileChange}
              accept=".csv,.tsv,.xlsx,.fasta,.vcf,.txt"
            />
            {file ? (
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="space-y-4"
              >
                <div className="w-20 h-20 rounded-2xl bg-cyan-500/20 flex items-center justify-center mx-auto">
                  <FileText className="w-10 h-10 text-cyan-400" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white mb-1">{file.name}</h4>
                  <p className="text-sm text-[#8E9299]">{(file.size / (1024 * 1024)).toFixed(2)} MB • READY_FOR_UPLOAD</p>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); setFile(null); }}
                  className="px-4 py-2 bg-red-500/10 text-red-500 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-red-500/20 transition-all border border-red-500/20"
                >
                  Remove File
                </button>
              </motion.div>
            ) : (
              <>
                <div className="w-20 h-20 rounded-2xl bg-[#111] flex items-center justify-center mb-6">
                  <UploadIcon className="w-10 h-10 text-[#4A4A4A]" />
                </div>
                <h4 className="text-xl font-bold text-white mb-2">Drop payload here</h4>
                <p className="text-[#8E9299] max-w-[240px] text-sm leading-relaxed">
                  Support for CSV, TSV, XLSX, FASTA, VCF. Max 500MB per sequence.
                </p>
              </>
            )}
          </div>

          <div className="p-4 bg-[#111] rounded-2xl border border-[#222] flex items-start gap-3">
             <div className="p-2 bg-cyan-500/10 rounded-lg mt-0.5">
               <Info className="w-4 h-4 text-cyan-500" />
             </div>
             <p className="text-[10px] text-[#8E9299] leading-relaxed uppercase tracking-wider">
               Datasets are encrypted at rest and automatically processed through our quality control module upon ingestion.
             </p>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {success && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed bottom-8 right-8 bg-green-500 text-black px-6 py-4 rounded-2xl font-bold shadow-2xl flex items-center gap-3 z-50"
          >
            <CheckCircle2 className="w-6 h-6" />
            INGESTION_COMPLETE: ACCESS DATA IN DASHBOARD
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
